// MainActivity.java
package my.schedulemanagemerapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;

import android.app.DatePickerDialog;

public class MainActivity extends AppCompatActivity {

    public String fname = null;
    public String str = null;
    public CalendarView calendarView;
    public Button cha_Btn, del_Btn, save_Btn;
    public TextView diaryTextView, textView2, textView3;
    public EditText contextEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendarView = findViewById(R.id.calendarView);
        diaryTextView = findViewById(R.id.diaryTextView);
        save_Btn = findViewById(R.id.save_Btn);
        del_Btn = findViewById(R.id.del_Btn);
        cha_Btn = findViewById(R.id.cha_Btn);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        contextEditText = findViewById(R.id.contextEditText);

        Intent intent = getIntent();
        final String userID = intent.getStringExtra("userID");

        textView3.setText("일정 매니저");

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                diaryTextView.setVisibility(View.VISIBLE);
                save_Btn.setVisibility(View.VISIBLE);
                contextEditText.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);

                // 음력 날짜 계산
                String lunarDate = LunarCalendar.getLunarDate(year, month, dayOfMonth);
                diaryTextView.setText(String.format("%d / %d / %d (%s)", year, month + 1, dayOfMonth, lunarDate));

                contextEditText.setText("");
                checkDay(year, month, dayOfMonth, userID);
            }
        });

        // 날짜 텍스트 클릭 시 DatePickerDialog 표시
        diaryTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();

                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        (view1, year, month, dayOfMonth) -> {
                            Calendar selectedDate = Calendar.getInstance();
                            selectedDate.set(year, month, dayOfMonth);
                            calendarView.setDate(selectedDate.getTimeInMillis(), true, true);

                            // 음력 날짜 갱신
                            String lunarDate = LunarCalendar.getLunarDate(year, month, dayOfMonth);
                            diaryTextView.setText(String.format("%d / %d / %d (%s)", year, month + 1, dayOfMonth, lunarDate));

                            checkDay(year, month, dayOfMonth, userID);
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                );

                datePickerDialog.show();
            }
        });

        save_Btn.setOnClickListener(view -> {
            saveDiary(fname);
            str = contextEditText.getText().toString();
            textView2.setText(str);
            save_Btn.setVisibility(View.INVISIBLE);
            cha_Btn.setVisibility(View.VISIBLE);
            del_Btn.setVisibility(View.VISIBLE);
            contextEditText.setVisibility(View.INVISIBLE);
            textView2.setVisibility(View.VISIBLE);
        });
    }

    public void checkDay(int cYear, int cMonth, int cDay, String userID) {
        fname = "" + userID + cYear + "-" + (cMonth + 1) + "-" + cDay + ".txt";
        FileInputStream fis;

        try {
            fis = openFileInput(fname);
            byte[] fileData = new byte[fis.available()];
            fis.read(fileData);
            fis.close();

            str = new String(fileData);

            contextEditText.setVisibility(View.INVISIBLE);
            textView2.setVisibility(View.VISIBLE);
            textView2.setText(str);

            save_Btn.setVisibility(View.INVISIBLE);
            cha_Btn.setVisibility(View.VISIBLE);
            del_Btn.setVisibility(View.VISIBLE);

            cha_Btn.setOnClickListener(view -> {
                contextEditText.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                contextEditText.setText(str);
                save_Btn.setVisibility(View.VISIBLE);
                cha_Btn.setVisibility(View.INVISIBLE);
                del_Btn.setVisibility(View.INVISIBLE);
            });

            del_Btn.setOnClickListener(view -> {
                // 삭제 후 초기화 코드
                textView2.setVisibility(View.INVISIBLE);  // 기존 메모 내용 숨기기
                contextEditText.setText("");  // 입력창 초기화
                contextEditText.setVisibility(View.VISIBLE);  // 입력창 보이기
                diaryTextView.setVisibility(View.VISIBLE);  // 날짜 보이기
                save_Btn.setVisibility(View.VISIBLE);  // 저장 버튼 보이기
                cha_Btn.setVisibility(View.INVISIBLE);  // 수정 버튼 숨기기
                del_Btn.setVisibility(View.INVISIBLE);  // 삭제 버튼 숨기기

                // 파일 내용 삭제
                removeDiary(fname);
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    public void removeDiary(String readDay) {
        try (FileOutputStream fos = openFileOutput(readDay, MODE_NO_LOCALIZED_COLLATORS)) {
            fos.write("".getBytes());  // 내용 비우기
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    public void saveDiary(String readDay) {
        try (FileOutputStream fos = openFileOutput(readDay, MODE_NO_LOCALIZED_COLLATORS)) {
            String content = contextEditText.getText().toString();
            fos.write(content.getBytes());  // 메모 저장
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

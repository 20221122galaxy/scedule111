package my.schedulemanagemerapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.HashSet;

public class DotOverlayView extends View {
    private final Paint paint = new Paint();
    private final HashSet<Long> dotDates = new HashSet<>();

    public DotOverlayView(Context context) {
        super(context);
        paint.setColor(Color.RED); // 점 색상
        paint.setAntiAlias(true);
    }

    public void setDotDates(HashSet<Long> dates) {
        dotDates.clear();
        dotDates.addAll(dates);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // 여기에서 CalendarView 위의 점 위치를 계산해 그립니다.
        // 기본 CalendarView는 직접 날짜 위치를 알 수 없기 때문에 완벽한 정렬은 어렵지만 대략적으로 표시 가능합니다.
        // 더 정확한 정렬을 원하면 `RecyclerView` 기반 캘린더 라이브러리를 사용하는 것이 좋습니다.
    }
}

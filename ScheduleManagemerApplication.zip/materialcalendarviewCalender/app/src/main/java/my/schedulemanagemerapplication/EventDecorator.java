package my.schedulemanagemerapplication;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

public class EventDecorator implements DayViewDecorator {
    private final int color;
    private final CalendarDay date;

    public EventDecorator(int color, CalendarDay date) {
        this.color = color;
        this.date = date;
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return day.equals(date);
    }

    @Override
    public void decorate(DayViewFacade view) {
        // ColorDrawable을 사용하여 배경 색을 설정
        view.setBackgroundDrawable(new ColorDrawable(color));
    }
}

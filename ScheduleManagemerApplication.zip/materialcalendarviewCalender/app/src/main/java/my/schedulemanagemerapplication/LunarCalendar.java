// LunarCalendar.java
package my.schedulemanagemerapplication;

import android.icu.util.ChineseCalendar;
import java.util.Calendar;

public class LunarCalendar {
    public static String getLunarDate(int year, int month, int day) {
        // 양력 기준 Calendar 생성
        Calendar gregorian = Calendar.getInstance();
        gregorian.set(year, month, day);

        // ChineseCalendar로 변환
        ChineseCalendar cc = new ChineseCalendar();
        cc.setTimeInMillis(gregorian.getTimeInMillis());

        int lunarMonth = cc.get(ChineseCalendar.MONTH) + 1;
        int lunarDay = cc.get(ChineseCalendar.DAY_OF_MONTH);
        boolean isLeapMonth = cc.get(ChineseCalendar.IS_LEAP_MONTH) == 1;

        return String.format("음력: %s%d월 %d일", (isLeapMonth ? "윤" : ""), lunarMonth, lunarDay);
    }
}

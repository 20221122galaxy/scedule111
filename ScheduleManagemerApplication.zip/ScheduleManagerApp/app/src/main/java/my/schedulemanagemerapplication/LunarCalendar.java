// LunarCalendar.java
package my.schedulemanagemerapplication;

import android.icu.util.ChineseCalendar;
import java.util.Calendar;

public class LunarCalendar {
    public static String getLunarDate(int year, int month, int day) {
        ChineseCalendar cc = new ChineseCalendar();
        cc.set(Calendar.YEAR, year);
        cc.set(Calendar.MONTH, month);
        cc.set(Calendar.DAY_OF_MONTH, day);

        int lunarYear = cc.get(ChineseCalendar.EXTENDED_YEAR) - 2637;
        int lunarMonth = cc.get(ChineseCalendar.MONTH) + 1;
        int lunarDay = cc.get(ChineseCalendar.DAY_OF_MONTH);
        boolean isLeapMonth = cc.get(ChineseCalendar.IS_LEAP_MONTH) == 1;

        return String.format("음력: %s%d월 %d일", (isLeapMonth ? "윤" : ""), lunarMonth, lunarDay);
    }
}
